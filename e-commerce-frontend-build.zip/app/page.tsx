import { EcommerceStore } from "@/components/ecommerce-store"

export default function Home() {
  return <EcommerceStore />
}
