import type { Product } from "./mock-data"

export interface Filters {
  categories: string[]
  colors: string[]
  materials: string[]
  priceRange: {
    min: number
    max: number
  }
}

export interface CartItem {
  product: Product
  quantity: number
}

export interface User {
  email: string
  name: string
  phone: string
  loyaltyPoints: number
  purchaseHistory: string[] // product IDs
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}
