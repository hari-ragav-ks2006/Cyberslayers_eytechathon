"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import type { User, AuthState } from "./types"

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => boolean
  signup: (email: string, phone: string, password: string, name: string) => boolean
  logout: () => void
  addLoyaltyPoints: (points: number) => void
  addPurchase: (productId: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
  })

  const signup = (email: string, phone: string, password: string, name: string) => {
    const newUser: User = {
      email,
      name,
      phone,
      loyaltyPoints: 0,
      purchaseHistory: [],
    }
    setAuthState({ user: newUser, isAuthenticated: true })
    return true
  }

  const login = (email: string, password: string) => {
    const user: User = {
      email,
      name: email.split("@")[0],
      phone: "9876543210",
      loyaltyPoints: 150,
      purchaseHistory: ["prod-032"], // Previously bought black jeans
    }
    setAuthState({ user, isAuthenticated: true })
    return true
  }

  const logout = () => {
    setAuthState({ user: null, isAuthenticated: false })
  }

  const addLoyaltyPoints = (points: number) => {
    setAuthState((prev) => {
      if (!prev.user) return prev
      return {
        ...prev,
        user: { ...prev.user, loyaltyPoints: prev.user.loyaltyPoints + points },
      }
    })
  }

  const addPurchase = (productId: string) => {
    setAuthState((prev) => {
      if (!prev.user) return prev
      return {
        ...prev,
        user: {
          ...prev.user,
          purchaseHistory: [...prev.user.purchaseHistory, productId],
        },
      }
    })
  }

  return (
    <AuthContext.Provider value={{ ...authState, login, signup, logout, addLoyaltyPoints, addPurchase }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used within AuthProvider")
  return context
}
