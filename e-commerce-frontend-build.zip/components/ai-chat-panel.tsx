"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Send, ShoppingCart, Zap, Share2, Sparkles } from "lucide-react"
import { Input } from "@/components/ui/input"
import type { Filters } from "@/lib/types"
import type { Product } from "@/lib/mock-data"
import { CATEGORIES, COLORS, MATERIALS } from "@/lib/mock-data"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { Toast } from "@/components/toast"
import { AuthModal } from "@/components/auth-modal"
import { SizeSelectionModal } from "@/components/size-selection-modal"
import { EnhancedCheckoutModal } from "@/components/enhanced-checkout-modal"
import { BuybotLogo } from "@/components/buybot-logo"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  products?: Product[]
  isRecommendation?: boolean
}

interface AIChatPanelProps {
  products: Product[]
  allProducts: Product[]
  onFilterApply: (filters: Filters) => void
  onProductSelect: (product: Product) => void
}

export function AIChatPanel({ products, allProducts, onFilterApply, onProductSelect }: AIChatPanelProps) {
  const { addToCart } = useCart()
  const { isAuthenticated, user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        'Hi! I\'m BuyBot AI, your smart shopping assistant. Ask me to find clothes - try "show me white cap" or "find red shorts".',
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null)
  const [sizeSelectionProduct, setSizeSelectionProduct] = useState<Product | null>(null)
  const [selectedSize, setSelectedSize] = useState<string>("")
  const [searchHistory, setSearchHistory] = useState<string[]>([])
  const [hasShownInitialRecommendation, setHasShownInitialRecommendation] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    if (!hasShownInitialRecommendation && allProducts.length > 0) {
      setHasShownInitialRecommendation(true)
      setTimeout(() => {
        showProactiveRecommendation()
      }, 2000)
    }
  }, [allProducts, hasShownInitialRecommendation])

  const formatPrice = (price: number) => `₹${price.toLocaleString("en-IN")}`

  const getSeasonalRecommendations = () => {
    const winterItems = allProducts.filter(
      (p) => p.category === "Jacket" || p.category === "Sweater" || p.category === "Cardigan",
    )
    return winterItems.slice(0, 4)
  }

  const getComplementaryProducts = (recentSearch: string) => {
    const lower = recentSearch.toLowerCase()
    // If they searched for pants/jeans, recommend shirts
    if (lower.includes("jeans") || lower.includes("pants")) {
      return allProducts.filter((p) => p.category === "Shirt" || p.category === "T-Shirt").slice(0, 4)
    }
    // If they searched for shirts, recommend pants
    if (lower.includes("shirt") || lower.includes("tee")) {
      return allProducts.filter((p) => p.category === "Jeans").slice(0, 4)
    }
    // If they searched for a color, find matching items in different category
    const colorMatch = COLORS.find((c) => lower.includes(c.toLowerCase()))
    if (colorMatch) {
      return allProducts.filter((p) => p.color === colorMatch).slice(0, 4)
    }
    return []
  }

  const showProactiveRecommendation = () => {
    const recommendations: Message[] = []

    // Check if it's winter season (Nov-Feb) - for demo, always show winter recommendations
    const winterProducts = getSeasonalRecommendations()
    if (winterProducts.length > 0) {
      recommendations.push({
        id: `rec-winter-${Date.now()}`,
        role: "assistant",
        content:
          "❄️ Winter Season Alert! It's getting cold outside. Check out these cozy jackets and sweaters to keep you warm:",
        products: winterProducts,
        isRecommendation: true,
      })
    }

    // Show recommendations based on search history
    if (searchHistory.length > 0) {
      const lastSearch = searchHistory[searchHistory.length - 1]
      const complementary = getComplementaryProducts(lastSearch)
      if (complementary.length > 0) {
        recommendations.push({
          id: `rec-match-${Date.now()}`,
          role: "assistant",
          content: `💡 Based on your interest in ${lastSearch}, here are perfect matches to complete your outfit:`,
          products: complementary,
          isRecommendation: true,
        })
      }
    }

    if (recommendations.length > 0) {
      setMessages((prev) => [...prev, recommendations[0]])
    }
  }

  const parseQuery = (query: string) => {
    const lowerQuery = query.toLowerCase()

    const isRecommendation = lowerQuery.includes("recommend") || lowerQuery.includes("suggestion")

    const matchedCategories = CATEGORIES.filter((cat) => lowerQuery.includes(cat.toLowerCase()))
    const matchedColors = COLORS.filter((color) => lowerQuery.includes(color.toLowerCase()))
    const matchedMaterials = MATERIALS.filter((material) => lowerQuery.includes(material.toLowerCase()))

    let minPrice = 0
    let maxPrice = 50000

    const underMatch = lowerQuery.match(/(?:under|below|less than)\s*₹?(\d+)/i)
    if (underMatch) maxPrice = Number.parseInt(underMatch[1])

    const overMatch = lowerQuery.match(/(?:over|above|more than)\s*₹?(\d+)/i)
    if (overMatch) minPrice = Number.parseInt(overMatch[1])

    const betweenMatch = lowerQuery.match(/between\s*₹?(\d+)\s*(?:and|-)\s*₹?(\d+)/i)
    if (betweenMatch) {
      minPrice = Number.parseInt(betweenMatch[1])
      maxPrice = Number.parseInt(betweenMatch[2])
    }

    return {
      categories: matchedCategories,
      colors: matchedColors,
      materials: matchedMaterials,
      priceRange: { min: minPrice, max: maxPrice },
      isRecommendation,
    }
  }

  const filterProducts = (filters: Filters) => {
    return allProducts.filter((product) => {
      if (filters.categories.length > 0 && !filters.categories.includes(product.category)) return false
      if (filters.colors.length > 0 && !filters.colors.includes(product.color)) return false
      if (filters.materials.length > 0 && !filters.materials.includes(product.material)) return false
      if (product.price < filters.priceRange.min || product.price > filters.priceRange.max) return false
      return true
    })
  }

  const checkForDiscountQuery = (query: string) => {
    const lowerQuery = query.toLowerCase()
    const discountKeywords = ["discount", "promo", "code", "coupon", "offer", "deal", "save"]
    return discountKeywords.some((keyword) => lowerQuery.includes(keyword))
  }

  const generateResponse = (
    filters: Filters,
    matchedProducts: Product[],
    isDiscountQuery: boolean,
    isRecommendation: boolean,
  ) => {
    if (isDiscountQuery) {
      return "🎉 Great news! Use code FASHION20 to get 20% off your entire purchase at checkout. All products are already discounted!"
    }

    if (isRecommendation && searchHistory.length > 0) {
      const lastSearch = searchHistory[searchHistory.length - 1]
      return `Based on your interest in ${lastSearch}, here are some recommendations for you:`
    }

    const parts: string[] = []
    if (filters.colors.length > 0) parts.push(filters.colors.join(" AND ").toLowerCase())
    if (filters.materials.length > 0) parts.push(filters.materials.join(" AND ").toLowerCase())
    if (filters.categories.length > 0) parts.push(filters.categories.join(" AND ").toLowerCase())

    const hasPriceFilter = filters.priceRange.min > 0 || filters.priceRange.max < 50000

    if (parts.length === 0 && !hasPriceFilter) {
      return `Showing all ${matchedProducts.length} products. What are you looking for?`
    }

    let response = `Found ${matchedProducts.length} `
    if (parts.length > 0) {
      response += parts.join(" ") + " items"
    } else {
      response += "items"
    }

    if (hasPriceFilter) {
      if (filters.priceRange.min > 0 && filters.priceRange.max < 50000) {
        response += ` between ${formatPrice(filters.priceRange.min)}-${formatPrice(filters.priceRange.max)}`
      } else if (filters.priceRange.min > 0) {
        response += ` over ${formatPrice(filters.priceRange.min)}`
      } else if (filters.priceRange.max < 50000) {
        response += ` under ${formatPrice(filters.priceRange.max)}`
      }
    }

    return response
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
    }
    setMessages((prev) => [...prev, userMessage])

    const parsed = parseQuery(input)
    if (parsed.categories.length > 0 || parsed.colors.length > 0) {
      const searchTerm = [...parsed.colors, ...parsed.categories].join(" ")
      setSearchHistory((prev) => [...prev, searchTerm])
    }

    setInput("")
    setIsTyping(true)

    await new Promise((resolve) => setTimeout(resolve, 400))

    const isDiscountQuery = checkForDiscountQuery(input)
    const parsedFilters = parseQuery(input)

    if (!isDiscountQuery) {
      onFilterApply(parsedFilters)
    }

    const matchedProducts = filterProducts(parsedFilters)
    const response = generateResponse(parsedFilters, matchedProducts, isDiscountQuery, parsedFilters.isRecommendation)

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: response,
      products: isDiscountQuery ? undefined : matchedProducts.slice(0, 4),
    }

    setIsTyping(false)
    setMessages((prev) => [...prev, assistantMessage])

    // Show proactive recommendations after user searches
    if (searchHistory.length > 0 && Math.random() > 0.5) {
      setTimeout(() => {
        showProactiveRecommendation()
      }, 3000)
    }
  }

  const handleClearFilters = () => {
    onFilterApply({
      categories: [],
      colors: [],
      materials: [],
      priceRange: { min: 0, max: 50000 },
    })
    const clearMessage: Message = {
      id: Date.now().toString(),
      role: "assistant",
      content: "Filters cleared! Showing all products.",
    }
    setMessages((prev) => [...prev, clearMessage])
  }

  const handleAddToCart = (product: Product) => {
    addToCart(product)
    setToastMessage("Item added to cart successfully")
  }

  const handleBuyNow = (product: Product) => {
    if (!isAuthenticated) {
      setShowAuthModal(true)
      setCheckoutProduct(product)
      return
    }
    setSizeSelectionProduct(product)
  }

  const handleSizeSelected = (size: string) => {
    setSelectedSize(size)
    setSizeSelectionProduct(null)
    if (sizeSelectionProduct) {
      setCheckoutProduct(sizeSelectionProduct)
    }
  }

  const handleShare = (product: Product) => {
    const productUrl = `https://styleai.store/product/${product.id}`
    navigator.clipboard.writeText(productUrl)
    setToastMessage("Link copied to clipboard")
  }

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col bg-gray-950">
      {/* Header */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 text-cyan-400">
            <BuybotLogo />
          </div>
          <div>
            <h2 className="font-semibold text-white text-sm">BuyBot AI Assistant</h2>
            <p className="text-xs text-gray-500">Smart shopping recommendations</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[95%] ${message.role === "user" ? "" : "w-full"}`}>
              <div
                className={`rounded-xl px-3 py-2 text-sm ${
                  message.role === "user"
                    ? "bg-cyan-600 text-white"
                    : message.isRecommendation
                      ? "bg-gradient-to-r from-cyan-900/50 to-purple-900/50 text-white border border-cyan-600/30"
                      : "bg-gray-800 text-gray-200"
                }`}
              >
                {message.isRecommendation && (
                  <div className="flex items-center gap-1 mb-1">
                    <Sparkles className="h-3 w-3 text-cyan-400" />
                    <span className="text-xs text-cyan-400 font-medium">Smart Recommendation</span>
                  </div>
                )}
                <p className="leading-relaxed">{message.content}</p>
              </div>

              {message.products && message.products.length > 0 && (
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {message.products.map((product) => (
                    <div
                      key={product.id}
                      className="group bg-gray-900 border border-gray-800 rounded-lg overflow-hidden hover:border-cyan-600/50 transition-all"
                    >
                      <button onClick={() => onProductSelect(product)} className="w-full text-left">
                        <div className="aspect-square bg-gray-800 overflow-hidden relative">
                          <img
                            src={product.image || "/placeholder.svg"}
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                          />
                          <button
                            onClick={(e) => {
                              e.stopPropagation()
                              handleShare(product)
                            }}
                            className="absolute top-1 right-1 h-6 w-6 bg-gray-900/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Share2 className="h-3 w-3 text-white" />
                          </button>
                        </div>
                        <div className="p-2">
                          <p className="text-xs font-medium text-white line-clamp-1">{product.name}</p>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <p className="text-xs font-bold text-cyan-400">{formatPrice(product.price)}</p>
                            <p className="text-[10px] text-gray-500 line-through">
                              {formatPrice(product.originalPrice)}
                            </p>
                          </div>
                        </div>
                      </button>
                      <div className="px-2 pb-2 flex gap-1">
                        <button
                          onClick={() => handleAddToCart(product)}
                          className="flex-1 h-7 bg-gray-800 text-gray-400 rounded text-[10px] font-medium flex items-center justify-center gap-1 hover:bg-gray-700 hover:text-white transition-colors"
                        >
                          <ShoppingCart className="h-3 w-3" />
                          Cart
                        </button>
                        <button
                          onClick={() => handleBuyNow(product)}
                          className="flex-1 h-7 bg-cyan-600 text-white rounded text-[10px] font-medium flex items-center justify-center gap-1 hover:bg-cyan-500 transition-colors"
                        >
                          <Zap className="h-3 w-3" />
                          Buy
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-800 rounded-xl px-3 py-2">
              <span className="inline-flex gap-1 text-gray-500">
                <span className="animate-bounce text-xs">●</span>
                <span className="animate-bounce text-xs" style={{ animationDelay: "0.1s" }}>
                  ●
                </span>
                <span className="animate-bounce text-xs" style={{ animationDelay: "0.2s" }}>
                  ●
                </span>
              </span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick actions */}
      <div className="px-3 pb-2">
        <div className="flex flex-wrap gap-1">
          {["Winter Jacket", "Black Jeans", "White Shirt", "Discount Code"].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setInput(suggestion)}
              className="text-xs px-2 py-1 bg-gray-800 text-gray-400 rounded-full hover:bg-gray-700 hover:text-white transition-colors"
            >
              {suggestion}
            </button>
          ))}
          <button
            onClick={handleClearFilters}
            className="text-xs px-2 py-1 bg-cyan-600/20 text-cyan-400 rounded-full hover:bg-cyan-600/30 transition-colors"
          >
            Clear
          </button>
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-gray-800 p-3">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search products..."
            className="flex-1 h-9 bg-gray-900 border-gray-700 text-white text-sm placeholder:text-gray-500"
          />
          <button
            type="submit"
            disabled={!input.trim() || isTyping}
            className="h-9 w-9 rounded-lg bg-cyan-600 text-white flex items-center justify-center hover:bg-cyan-500 transition-colors disabled:opacity-50"
          >
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>

      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}

      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => {
            setShowAuthModal(false)
            if (checkoutProduct) {
              setSizeSelectionProduct(checkoutProduct)
            }
          }}
        />
      )}

      {sizeSelectionProduct && (
        <SizeSelectionModal
          product={sizeSelectionProduct}
          onClose={() => setSizeSelectionProduct(null)}
          onSizeSelected={handleSizeSelected}
        />
      )}

      {checkoutProduct && selectedSize && (
        <EnhancedCheckoutModal
          product={checkoutProduct}
          selectedSize={selectedSize}
          onClose={() => {
            setCheckoutProduct(null)
            setSelectedSize("")
          }}
        />
      )}
    </div>
  )
}
