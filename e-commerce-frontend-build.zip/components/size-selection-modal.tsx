"use client"

import { useState } from "react"
import { X, ChevronRight } from "lucide-react"
import type { Product } from "@/lib/mock-data"

interface SizeSelectionModalProps {
  product: Product
  onClose: () => void
  onSizeSelected: (size: string) => void
}

export function SizeSelectionModal({ product, onClose, onSizeSelected }: SizeSelectionModalProps) {
  const [selectedSize, setSelectedSize] = useState<string>("")

  const getSizeOptions = () => {
    const category = product.category.toLowerCase()

    // Men's clothing - numeric sizes
    if (category === "shirt" || category === "blazer" || category === "jacket") {
      return ["28", "30", "32", "34", "36", "38", "40"]
    }

    // Women's clothing - numeric sizes
    if (category === "dress" || category === "blouse" || category === "skirt") {
      return ["20", "22", "24", "26", "28", "30"]
    }

    // Default - letter sizes
    return ["S", "M", "L", "XL"]
  }

  const sizes = getSizeOptions()

  const handleContinue = () => {
    if (selectedSize) {
      onSizeSelected(selectedSize)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-md">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
        >
          <X className="h-4 w-4 text-white" />
        </button>

        <div className="p-6">
          <h2 className="text-xl font-bold text-white mb-4">Select Size</h2>

          <div className="flex gap-3 mb-4">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              className="w-20 h-20 object-cover rounded-lg"
            />
            <div>
              <p className="text-white font-medium line-clamp-2">{product.name}</p>
              <p className="text-cyan-400 text-sm mt-1">₹{product.price.toLocaleString("en-IN")}</p>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 mb-6">
            {sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`h-12 rounded-lg font-medium transition-all ${
                  selectedSize === size
                    ? "bg-cyan-600 text-white border-2 border-cyan-400"
                    : "bg-gray-800 text-gray-300 border border-gray-700 hover:border-gray-600"
                }`}
              >
                {size}
              </button>
            ))}
          </div>

          <button
            onClick={handleContinue}
            disabled={!selectedSize}
            className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continue
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  )
}
