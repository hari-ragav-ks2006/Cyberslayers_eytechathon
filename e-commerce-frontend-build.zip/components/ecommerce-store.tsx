"use client"

import { useState, useMemo } from "react"
import { Header } from "@/components/header"
import { AIChatPanel } from "@/components/ai-chat-panel"
import { ProductGrid } from "@/components/product-grid"
import { ProductDetailModal } from "@/components/product-detail-modal"
import { generateMockProducts, type Product } from "@/lib/mock-data"
import type { Filters } from "@/lib/types"
import { CartProvider } from "@/lib/cart-context"
import { AuthProvider } from "@/lib/auth-context"

function StoreContent() {
  const [products] = useState<Product[]>(generateMockProducts())
  const [filters, setFilters] = useState<Filters>({
    categories: [],
    colors: [],
    materials: [],
    priceRange: { min: 0, max: 50000 },
  })
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      if (filters.categories.length > 0 && !filters.categories.includes(product.category)) {
        return false
      }
      if (filters.colors.length > 0 && !filters.colors.includes(product.color)) {
        return false
      }
      if (filters.materials.length > 0 && !filters.materials.includes(product.material)) {
        return false
      }
      if (product.price < filters.priceRange.min || product.price > filters.priceRange.max) {
        return false
      }
      return true
    })
  }, [products, filters])

  return (
    <div className="min-h-screen bg-gray-950 flex flex-col">
      <Header />
      <main className="flex-1 flex">
        <div className="flex-1 w-3/4">
          <ProductGrid products={filteredProducts} onProductSelect={setSelectedProduct} />
        </div>
        <div className="w-1/4 border-l border-gray-800">
          <AIChatPanel
            products={filteredProducts}
            allProducts={products}
            onFilterApply={setFilters}
            onProductSelect={setSelectedProduct}
          />
        </div>
      </main>
      {selectedProduct && <ProductDetailModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />}
    </div>
  )
}

export function EcommerceStore() {
  return (
    <AuthProvider>
      <CartProvider>
        <StoreContent />
      </CartProvider>
    </AuthProvider>
  )
}
