"use client"

import { User, ShoppingCart, LogOut, Award } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { useState } from "react"
import { BuybotLogo } from "@/components/buybot-logo"

export function Header() {
  const { totalItems } = useCart()
  const { user, isAuthenticated, logout } = useAuth()
  const [showDropdown, setShowDropdown] = useState(false)

  return (
    <header className="sticky top-0 z-40 border-b border-gray-800 bg-gray-900">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 text-cyan-400">
            <BuybotLogo />
          </div>
          <div className="text-xl font-semibold text-white tracking-tight">
            Buy<span className="text-cyan-400">Bot AI</span>
          </div>
        </div>
        {/* </CHANGE> */}

        <div className="flex items-center gap-1">
          {isAuthenticated && user ? (
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center gap-2 px-4 py-2 text-white hover:bg-gray-800 rounded-lg transition-colors"
              >
                <User className="h-5 w-5" />
                <div className="hidden sm:block text-left">
                  <p className="text-sm font-medium">{user.name}</p>
                  <p className="text-cyan-400 text-xs flex items-center gap-1">
                    <Award className="h-3 w-3" />
                    {user.loyaltyPoints} Points
                  </p>
                </div>
              </button>
              {showDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-gray-800 border border-gray-700 rounded-lg shadow-xl">
                  <div className="p-3 border-b border-gray-700">
                    <p className="text-white text-sm font-medium">{user.email}</p>
                    <p className="text-cyan-400 text-xs mt-1">Loyalty: {user.loyaltyPoints} points</p>
                  </div>
                  <button
                    onClick={() => {
                      logout()
                      setShowDropdown(false)
                    }}
                    className="w-full px-3 py-2 text-left text-gray-300 hover:bg-gray-700 flex items-center gap-2"
                  >
                    <LogOut className="h-4 w-4" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button className="flex items-center gap-2 px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors">
              <User className="h-5 w-5" />
              <span className="hidden sm:inline text-sm font-medium">Login</span>
            </button>
          )}
          {/* </CHANGE> */}

          <button className="flex items-center gap-2 px-4 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors relative">
            <ShoppingCart className="h-5 w-5" />
            <span className="hidden sm:inline text-sm font-medium">Cart</span>
            {totalItems > 0 && (
              <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-cyan-600 text-[10px] text-white flex items-center justify-center font-medium">
                {totalItems}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  )
}
