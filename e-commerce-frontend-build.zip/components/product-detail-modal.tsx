"use client"

import { useState } from "react"
import { X, ShoppingCart, Heart, Share2, Zap } from "lucide-react"
import type { Product } from "@/lib/mock-data"
import { useCart } from "@/lib/cart-context"
import { Toast } from "@/components/toast"
import { CheckoutModal } from "@/components/checkout-modal"

interface ProductDetailModalProps {
  product: Product
  onClose: () => void
}

export function ProductDetailModal({ product, onClose }: ProductDetailModalProps) {
  const { addToCart } = useCart()
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [showCheckout, setShowCheckout] = useState(false)

  const formatPrice = (price: number) => `₹${price.toLocaleString("en-IN")}`

  const handleAddToCart = () => {
    addToCart(product)
    setToastMessage("Item added to cart successfully")
  }

  if (showCheckout) {
    return (
      <CheckoutModal
        product={product}
        onClose={() => {
          setShowCheckout(false)
          onClose()
        }}
      />
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-gray-900 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col md:flex-row border border-gray-800">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 h-10 w-10 rounded-full bg-gray-800/80 backdrop-blur-sm flex items-center justify-center hover:bg-gray-700 transition-colors border border-gray-700"
        >
          <X className="h-5 w-5 text-white" />
        </button>

        <div className="md:w-1/2 aspect-square md:aspect-auto bg-gray-800">
          <img src={product.image || "/placeholder.svg"} alt={product.name} className="w-full h-full object-cover" />
        </div>

        {/* Details */}
        <div className="md:w-1/2 p-6 flex flex-col">
          <div className="flex-1">
            <span className="text-xs font-medium text-cyan-400 uppercase tracking-wider">{product.category}</span>
            <h2 className="text-2xl font-semibold text-white mt-1">{product.name}</h2>
            <p className="text-3xl font-bold text-cyan-400 mt-3">{formatPrice(product.price)}</p>

            <div className="mt-6 space-y-4">
              <div>
                <span className="text-sm font-medium text-white">Color</span>
                <div className="mt-2 flex items-center gap-2">
                  <span className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm">{product.color}</span>
                </div>
              </div>

              <div>
                <span className="text-sm font-medium text-white">Material</span>
                <div className="mt-2 flex items-center gap-2">
                  <span className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm">{product.material}</span>
                </div>
              </div>

              <div>
                <span className="text-sm font-medium text-white">Size</span>
                <div className="mt-2 flex items-center gap-2">
                  <span className="px-3 py-1 bg-gray-800 text-gray-300 rounded-full text-sm">{product.size}</span>
                </div>
              </div>
            </div>

            <p className="mt-6 text-sm text-gray-400 leading-relaxed">{product.description}</p>
          </div>

          {/* Actions */}
          <div className="mt-6 space-y-3">
            <button
              onClick={() => setShowCheckout(true)}
              className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors"
            >
              <Zap className="h-5 w-5" />
              Buy Now
            </button>
            <button
              onClick={handleAddToCart}
              className="w-full h-12 bg-gray-800 border border-gray-700 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-gray-700 transition-colors"
            >
              <ShoppingCart className="h-5 w-5" />
              Add to Cart
            </button>
            <div className="flex gap-3">
              <button className="flex-1 h-10 border border-gray-700 rounded-xl text-gray-300 font-medium flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors">
                <Heart className="h-4 w-4" />
                Save
              </button>
              <button className="flex-1 h-10 border border-gray-700 rounded-xl text-gray-300 font-medium flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors">
                <Share2 className="h-4 w-4" />
                Share
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Toast */}
      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}
    </div>
  )
}
