"use client"

import type React from "react"
import { useState } from "react"
import { ShoppingCart, Zap, Share2, Tag } from "lucide-react"
import type { Product } from "@/lib/mock-data"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { Toast } from "@/components/toast"
import { AuthModal } from "@/components/auth-modal"
import { SizeSelectionModal } from "@/components/size-selection-modal"
import { EnhancedCheckoutModal } from "@/components/enhanced-checkout-modal"

interface ProductGridProps {
  products: Product[]
  onProductSelect: (product: Product) => void
}

export function ProductGrid({ products, onProductSelect }: ProductGridProps) {
  const { addToCart } = useCart()
  const { isAuthenticated } = useAuth()
  const [toastMessage, setToastMessage] = useState<string | null>(null)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [checkoutProduct, setCheckoutProduct] = useState<Product | null>(null)
  const [sizeSelectionProduct, setSizeSelectionProduct] = useState<Product | null>(null)
  const [selectedSize, setSelectedSize] = useState<string>("")

  const handleAddToCart = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation()
    addToCart(product)
    setToastMessage("Item added to cart successfully")
  }

  const handleBuyNow = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation()
    if (!isAuthenticated) {
      setShowAuthModal(true)
      setCheckoutProduct(product)
      return
    }
    setSizeSelectionProduct(product)
  }

  const handleSizeSelected = (size: string) => {
    setSelectedSize(size)
    setSizeSelectionProduct(null)
    if (sizeSelectionProduct) {
      setCheckoutProduct(sizeSelectionProduct)
    }
  }

  const handleShare = (e: React.MouseEvent, product: Product) => {
    e.stopPropagation()
    const productUrl = `https://styleai.store/product/${product.id}`
    navigator.clipboard.writeText(productUrl)
    setToastMessage("Link copied to clipboard")
  }

  const formatPrice = (price: number) => `₹${price.toLocaleString("en-IN")}`

  const calculateDiscount = (original: number, current: number) => {
    return Math.round(((original - current) / original) * 100)
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Our Collection</h1>
        <p className="text-gray-400 text-sm mt-1">
          {products.length} {products.length === 1 ? "item" : "items"} available
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => {
          const discount = calculateDiscount(product.originalPrice, product.price)
          return (
            <div
              key={product.id}
              className="group bg-gray-900 border border-gray-800 rounded-xl overflow-hidden hover:border-cyan-600/50 hover:shadow-lg hover:shadow-cyan-500/10 transition-all"
            >
              <button onClick={() => onProductSelect(product)} className="w-full text-left">
                <div className="aspect-square bg-gray-800 relative overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-md flex items-center gap-1">
                    <Tag className="h-3 w-3" />
                    {discount}% OFF
                  </div>
                  <button
                    onClick={(e) => handleShare(e, product)}
                    className="absolute top-2 right-2 h-8 w-8 bg-gray-900/80 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-800"
                  >
                    <Share2 className="h-4 w-4 text-white" />
                  </button>
                </div>
                <div className="p-3">
                  <p className="text-xs text-cyan-400 font-medium uppercase tracking-wide">{product.category}</p>
                  <p className="text-sm font-medium text-white line-clamp-2 mt-1">{product.name}</p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-2">
                      <p className="text-lg font-bold text-cyan-400">{formatPrice(product.price)}</p>
                      <p className="text-xs text-gray-500 line-through">{formatPrice(product.originalPrice)}</p>
                    </div>
                    <span className="text-xs text-gray-500">{product.color}</span>
                  </div>
                </div>
              </button>

              <div className="px-3 pb-3 flex gap-2">
                <button
                  onClick={(e) => handleAddToCart(e, product)}
                  className="flex-1 h-9 bg-gray-800 border border-gray-700 text-gray-300 rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 hover:bg-gray-700 hover:text-white transition-colors"
                >
                  <ShoppingCart className="h-3.5 w-3.5" />
                  Add to Cart
                </button>
                <button
                  onClick={(e) => handleBuyNow(e, product)}
                  className="flex-1 h-9 bg-cyan-600 text-white rounded-lg text-xs font-medium flex items-center justify-center gap-1.5 hover:bg-cyan-500 transition-colors"
                >
                  <Zap className="h-3.5 w-3.5" />
                  Buy Now
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {products.length === 0 && (
        <div className="text-center py-16">
          <p className="text-gray-400">No products match your criteria.</p>
          <p className="text-sm text-gray-500 mt-1">Try adjusting your search in the chat.</p>
        </div>
      )}

      {toastMessage && <Toast message={toastMessage} onClose={() => setToastMessage(null)} />}

      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => {
            setShowAuthModal(false)
            if (checkoutProduct) {
              setSizeSelectionProduct(checkoutProduct)
            }
          }}
        />
      )}

      {sizeSelectionProduct && (
        <SizeSelectionModal
          product={sizeSelectionProduct}
          onClose={() => setSizeSelectionProduct(null)}
          onSizeSelected={handleSizeSelected}
        />
      )}

      {checkoutProduct && selectedSize && (
        <EnhancedCheckoutModal
          product={checkoutProduct}
          selectedSize={selectedSize}
          onClose={() => {
            setCheckoutProduct(null)
            setSelectedSize("")
          }}
        />
      )}
    </div>
  )
}
