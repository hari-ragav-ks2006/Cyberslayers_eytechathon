"use client"

import type React from "react"

import { useState } from "react"
import { X, Mail, Phone, Lock, User } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useAuth } from "@/lib/auth-context"

interface AuthModalProps {
  onClose: () => void
  onSuccess: () => void
}

export function AuthModal({ onClose, onSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<"login" | "signup">("login")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [otp, setOtp] = useState("")
  const [otpSent, setOtpSent] = useState(false)
  const { login, signup } = useAuth()

  const handleSendOtp = () => {
    // Simulate OTP send - auto-fill with "1234"
    setOtp("1234")
    setOtpSent(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (mode === "signup") {
      if (!otpSent) {
        handleSendOtp()
        return
      }
      if (otp === "1234") {
        signup(email, phone, password, name)
        onSuccess()
      }
    } else {
      login(email, password)
      onSuccess()
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-md">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
        >
          <X className="h-4 w-4 text-white" />
        </button>

        <div className="p-6">
          <h2 className="text-2xl font-bold text-white mb-2">{mode === "login" ? "Welcome Back" : "Create Account"}</h2>
          <p className="text-gray-400 text-sm mb-6">
            {mode === "login" ? "Login to continue shopping" : "Sign up to start shopping"}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label className="text-sm text-gray-300 block mb-2">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-sm text-gray-300 block mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  required
                />
              </div>
            </div>

            {mode === "signup" && (
              <div>
                <label className="text-sm text-gray-300 block mb-2">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter your phone"
                    className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                    required
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-sm text-gray-300 block mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="pl-10 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  required
                />
              </div>
            </div>

            {mode === "signup" && otpSent && (
              <div>
                <label className="text-sm text-gray-300 block mb-2">OTP (Auto-filled)</label>
                <Input
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="Enter OTP"
                  className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  required
                />
                <p className="text-green-400 text-xs mt-1">OTP: 1234 (auto-filled)</p>
              </div>
            )}

            <button
              type="submit"
              className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium hover:bg-cyan-500 transition-colors"
            >
              {mode === "signup" && !otpSent ? "Send OTP" : mode === "login" ? "Login" : "Sign Up"}
            </button>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={() => {
                setMode(mode === "login" ? "signup" : "login")
                setOtpSent(false)
                setOtp("")
              }}
              className="text-cyan-400 text-sm hover:text-cyan-300 transition-colors"
            >
              {mode === "login" ? "Don't have an account? Sign up" : "Already have an account? Login"}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
