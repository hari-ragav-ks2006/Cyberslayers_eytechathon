"use client"

import { useState } from "react"
import { X, CreditCard, Smartphone, Truck, Check, ChevronRight, Package, MapPin } from "lucide-react"
import type { Product } from "@/lib/mock-data"
import { Input } from "@/components/ui/input"

interface CheckoutModalProps {
  product: Product
  onClose: () => void
}

type PaymentMethod = "card" | "upi" | "cod"
type CheckoutStep = "summary" | "payment" | "details" | "pin" | "success" | "tracking"

export function CheckoutModal({ product, onClose }: CheckoutModalProps) {
  const [step, setStep] = useState<CheckoutStep>("summary")
  const [promoCode, setPromoCode] = useState("")
  const [promoApplied, setPromoApplied] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null)
  const [cardNumber, setCardNumber] = useState("")
  const [expiry, setExpiry] = useState("")
  const [cvv, setCvv] = useState("")
  const [upiId, setUpiId] = useState("")
  const [pin, setPin] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const originalPrice = product.price
  const discount = promoApplied ? originalPrice * 0.2 : 0
  const finalPrice = originalPrice - discount

  const handleApplyPromo = () => {
    if (promoCode.toUpperCase() === "FASHION20") {
      setPromoApplied(true)
    }
  }

  const handlePaymentSelect = (method: PaymentMethod) => {
    setPaymentMethod(method)
    if (method === "cod") {
      setStep("success")
    } else {
      setStep("details")
    }
  }

  const handleDetailsNext = () => {
    setStep("pin")
  }

  const handlePinSubmit = async () => {
    if (pin.length < 4) return
    setIsProcessing(true)
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsProcessing(false)
    setStep("success")
  }

  const formatPrice = (price: number) => `₹${price.toLocaleString("en-IN")}`

  const trackingSteps = [
    { label: "Order Placed", completed: true, date: "Today, 2:30 PM" },
    { label: "Packed", completed: true, date: "Today, 4:00 PM" },
    { label: "Shipped", completed: false, date: "Expected Tomorrow" },
    { label: "Out for Delivery", completed: false, date: "Expected in 2 days" },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      <div className="relative bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
        >
          <X className="h-4 w-4 text-white" />
        </button>

        <div className="p-6">
          {/* Step 1: Order Summary */}
          {step === "summary" && (
            <div className="space-y-5">
              <h2 className="text-xl font-semibold text-white">Order Summary</h2>

              <div className="flex gap-4 p-4 bg-gray-800 rounded-xl">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-20 h-20 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <p className="text-white font-medium line-clamp-2">{product.name}</p>
                  <p className="text-cyan-400 text-sm mt-1">{product.category}</p>
                  <p className="text-white font-bold mt-2">{formatPrice(originalPrice)}</p>
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-sm text-gray-300">Promo Code</label>
                <div className="flex gap-2">
                  <Input
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Enter promo code"
                    className="flex-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                    disabled={promoApplied}
                  />
                  <button
                    onClick={handleApplyPromo}
                    disabled={promoApplied}
                    className="px-4 py-2 bg-cyan-600 text-white rounded-lg font-medium hover:bg-cyan-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {promoApplied ? "Applied" : "Apply"}
                  </button>
                </div>
                {promoApplied && (
                  <p className="text-green-400 text-sm flex items-center gap-1">
                    <Check className="h-4 w-4" /> 20% discount applied!
                  </p>
                )}
              </div>

              <div className="border-t border-gray-700 pt-4 space-y-2">
                <div className="flex justify-between text-gray-300">
                  <span>Subtotal</span>
                  <span>{formatPrice(originalPrice)}</span>
                </div>
                {promoApplied && (
                  <div className="flex justify-between text-green-400">
                    <span>Discount (20%)</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-white font-bold text-lg">
                  <span>Total</span>
                  <span className="text-cyan-400">{formatPrice(finalPrice)}</span>
                </div>
              </div>

              <button
                onClick={() => setStep("payment")}
                className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors"
              >
                Continue to Payment
                <ChevronRight className="h-5 w-5" />
              </button>
            </div>
          )}

          {/* Step 2: Payment Method */}
          {step === "payment" && (
            <div className="space-y-5">
              <h2 className="text-xl font-semibold text-white">Payment Method</h2>
              <p className="text-gray-400 text-sm">Select how you want to pay</p>

              <div className="space-y-3">
                <button
                  onClick={() => handlePaymentSelect("card")}
                  className="w-full p-4 bg-gray-800 border border-gray-700 rounded-xl flex items-center gap-4 hover:border-cyan-500 transition-colors"
                >
                  <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center">
                    <CreditCard className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Credit/Debit Card</p>
                    <p className="text-gray-400 text-sm">Visa, Mastercard, RuPay</p>
                  </div>
                </button>

                <button
                  onClick={() => handlePaymentSelect("upi")}
                  className="w-full p-4 bg-gray-800 border border-gray-700 rounded-xl flex items-center gap-4 hover:border-cyan-500 transition-colors"
                >
                  <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center">
                    <Smartphone className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">UPI</p>
                    <p className="text-gray-400 text-sm">Google Pay, PhonePe, Paytm</p>
                  </div>
                </button>

                <button
                  onClick={() => handlePaymentSelect("cod")}
                  className="w-full p-4 bg-gray-800 border border-gray-700 rounded-xl flex items-center gap-4 hover:border-cyan-500 transition-colors"
                >
                  <div className="h-12 w-12 bg-gray-700 rounded-lg flex items-center justify-center">
                    <Truck className="h-6 w-6 text-cyan-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-white font-medium">Cash on Delivery</p>
                    <p className="text-gray-400 text-sm">Pay when you receive</p>
                  </div>
                </button>
              </div>

              <button
                onClick={() => setStep("summary")}
                className="w-full h-10 text-gray-400 hover:text-white transition-colors"
              >
                Back to Summary
              </button>
            </div>
          )}

          {/* Step 3: Payment Details */}
          {step === "details" && (
            <div className="space-y-5">
              <h2 className="text-xl font-semibold text-white">
                {paymentMethod === "card" ? "Card Details" : "UPI Details"}
              </h2>

              {paymentMethod === "card" ? (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-gray-300 block mb-2">Card Number</label>
                    <Input
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, "").slice(0, 16))}
                      placeholder="1234 5678 9012 3456"
                      className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                    />
                  </div>
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <label className="text-sm text-gray-300 block mb-2">Expiry</label>
                      <Input
                        value={expiry}
                        onChange={(e) => setExpiry(e.target.value)}
                        placeholder="MM/YY"
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                    </div>
                    <div className="flex-1">
                      <label className="text-sm text-gray-300 block mb-2">CVV</label>
                      <Input
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, "").slice(0, 3))}
                        placeholder="123"
                        type="password"
                        className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="text-sm text-gray-300 block mb-2">UPI ID</label>
                  <Input
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="yourname@upi"
                    className="bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  />
                </div>
              )}

              <button
                onClick={handleDetailsNext}
                disabled={paymentMethod === "card" ? !cardNumber || !expiry || !cvv : !upiId}
                className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue
                <ChevronRight className="h-5 w-5" />
              </button>

              <button
                onClick={() => setStep("payment")}
                className="w-full h-10 text-gray-400 hover:text-white transition-colors"
              >
                Back
              </button>
            </div>
          )}

          {/* Step 4: Secure PIN */}
          {step === "pin" && (
            <div className="space-y-5">
              <h2 className="text-xl font-semibold text-white">Enter Secure PIN</h2>
              <p className="text-gray-400 text-sm">Enter your PIN to authorize the payment</p>

              <div className="flex justify-center">
                <Input
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, "").slice(0, 6))}
                  placeholder="● ● ● ●"
                  type="password"
                  className="w-48 h-14 text-center text-2xl tracking-widest bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, null, 0, "del"].map((key, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      if (key === "del") setPin((p) => p.slice(0, -1))
                      else if (key !== null && pin.length < 6) setPin((p) => p + key)
                    }}
                    className={`h-12 rounded-lg font-medium text-lg transition-colors ${
                      key === null
                        ? "invisible"
                        : key === "del"
                          ? "bg-gray-700 text-gray-300 hover:bg-gray-600"
                          : "bg-gray-800 text-white hover:bg-gray-700"
                    }`}
                  >
                    {key === "del" ? "⌫" : key}
                  </button>
                ))}
              </div>

              <button
                onClick={handlePinSubmit}
                disabled={pin.length < 4 || isProcessing}
                className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isProcessing ? (
                  <span className="flex items-center gap-2">
                    <span className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Processing...
                  </span>
                ) : (
                  <>
                    Pay {formatPrice(finalPrice)}
                    <ChevronRight className="h-5 w-5" />
                  </>
                )}
              </button>
            </div>
          )}

          {/* Step 5: Success */}
          {step === "success" && (
            <div className="space-y-6 text-center py-4">
              <div className="relative mx-auto w-20 h-20">
                <div className="absolute inset-0 bg-green-500/20 rounded-full animate-ping" />
                <div className="relative w-20 h-20 bg-green-500 rounded-full flex items-center justify-center">
                  <Check className="h-10 w-10 text-white" />
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-white">Payment Successful!</h2>
                <p className="text-gray-400 mt-2">
                  {paymentMethod === "cod"
                    ? "Your order has been placed. Pay on delivery."
                    : "Your payment has been processed successfully."}
                </p>
              </div>

              <div className="p-4 bg-gray-800 rounded-xl">
                <p className="text-gray-400 text-sm">Order Total</p>
                <p className="text-2xl font-bold text-cyan-400">{formatPrice(finalPrice)}</p>
              </div>

              <button
                onClick={() => setStep("tracking")}
                className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-cyan-500 transition-colors"
              >
                <Package className="h-5 w-5" />
                Track Order
              </button>

              <button onClick={onClose} className="w-full h-10 text-gray-400 hover:text-white transition-colors">
                Continue Shopping
              </button>
            </div>
          )}

          {/* Step 6: Order Tracking */}
          {step === "tracking" && (
            <div className="space-y-5">
              <h2 className="text-xl font-semibold text-white">Track Your Order</h2>

              <div className="flex gap-4 p-3 bg-gray-800 rounded-xl">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                <div>
                  <p className="text-white font-medium line-clamp-1">{product.name}</p>
                  <p className="text-gray-400 text-sm">Order #STY{Date.now().toString().slice(-8)}</p>
                </div>
              </div>

              <div className="space-y-1">
                {trackingSteps.map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          item.completed ? "bg-green-500" : "bg-gray-700"
                        }`}
                      >
                        {item.completed ? (
                          <Check className="h-4 w-4 text-white" />
                        ) : (
                          <span className="h-2 w-2 bg-gray-500 rounded-full" />
                        )}
                      </div>
                      {index < trackingSteps.length - 1 && (
                        <div className={`w-0.5 h-12 ${item.completed ? "bg-green-500" : "bg-gray-700"}`} />
                      )}
                    </div>
                    <div className="pb-8">
                      <p className={`font-medium ${item.completed ? "text-white" : "text-gray-500"}`}>{item.label}</p>
                      <p className="text-sm text-gray-400">{item.date}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 bg-gray-800 rounded-xl flex items-center gap-3">
                <MapPin className="h-5 w-5 text-cyan-400" />
                <div>
                  <p className="text-white text-sm font-medium">Delivery Address</p>
                  <p className="text-gray-400 text-sm">123 Fashion Street, Mumbai - 400001</p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full h-12 bg-cyan-600 text-white rounded-xl font-medium hover:bg-cyan-500 transition-colors"
              >
                Done
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
