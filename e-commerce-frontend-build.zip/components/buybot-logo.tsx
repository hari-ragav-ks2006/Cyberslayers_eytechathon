export function BuybotLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`relative ${className}`}>
      <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        {/* Shopping cart base */}
        <path
          d="M6 6L8 6L11 20L25 20"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M11 20C11 21.1046 10.1046 22 9 22C7.89543 22 7 21.1046 7 20C7 18.8954 7.89543 18 9 18C10.1046 18 11 18.8954 11 20Z"
          fill="currentColor"
        />
        <path
          d="M25 20C25 21.1046 24.1046 22 23 22C21.8954 22 21 21.1046 21 20C21 18.8954 21.8954 18 23 18C24.1046 18 25 18.8954 25 20Z"
          fill="currentColor"
        />
        <path
          d="M8 6L10 14L24 14L26 6L8 6Z"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* AI sparkle elements */}
        <circle
          cx="20"
          cy="8"
          r="1.5"
          fill="currentColor"
          className="animate-pulse"
          style={{ animationDelay: "0s", animationDuration: "2s" }}
        />
        <circle
          cx="24"
          cy="10"
          r="1"
          fill="currentColor"
          className="animate-pulse"
          style={{ animationDelay: "0.5s", animationDuration: "2s" }}
        />
        <circle
          cx="18"
          cy="4"
          r="1"
          fill="currentColor"
          className="animate-pulse"
          style={{ animationDelay: "1s", animationDuration: "2s" }}
        />

        {/* Neural network connection lines */}
        <path d="M20 8L24 10M18 4L20 8" stroke="currentColor" strokeWidth="0.5" strokeLinecap="round" opacity="0.4" />
      </svg>
    </div>
  )
}
